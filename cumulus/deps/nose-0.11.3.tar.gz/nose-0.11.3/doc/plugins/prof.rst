Prof: enable profiling using the hotshot profiler
=================================================

.. autoplugin :: nose.plugins.prof
