def setup():
    raise Exception("I would prefer not to")

def test():
    raise Exception("I should never run")
