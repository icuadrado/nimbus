from errorclass_failure_plugin import Todo

def test_todo():
    raise Todo("fix me")

def test_2():
    pass
